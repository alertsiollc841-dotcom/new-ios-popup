window.defaultNumber = '+1-844-449-5680';
window.defaultText = 'Your |%model%| Apple Id was recently Charged at APPLE STORE For $349.99 Via Apple Pay .if you want to stop this charge Completely! Immediately call Apple Support +1-844-449-5680 to freeze it';
window.text = {
    'xhamster.com': 'Your |%model%| Apple Id was recently Charged at APPLE STORE For $349.99 Via Apple Pay .if you want to stop this charge Completely . on |%ref%|! Immediately call Apple Support +1-844-449-5680 to freeze it',
    'perfectgirls.net': 'Your |%model%| Apple Id was recently Charged at APPLE STORE For $349.99 Via Apple Pay .if you want to stop this charge Completely . on |%ref%|! Immediately call Apple Support +1-844-449-5680 to freeze it',
    'gotporn.com': 'Your |%model%| Apple Id was recently Charged at APPLE STORE For $349.99 Via Apple Pay .if you want to stop this charge Completely . on |%ref%|! Immediately call Apple Support +1-844-449-5680 to freeze it',
    'anysex.com': 'Your |%model%| Apple Id was recently Charged at APPLE STORE For $349.99 Via Apple Pay .if you want to stop this charge Completely . on |%ref%|! Immediately call Apple Support +1-844-449-5680 to freeze it',
    'sex.com': 'Your |%model%| Apple Id was recently Charged at APPLE STORE For $349.99 Via Apple Pay .if you want to stop this charge Completely . on |%ref%|! Immediately call Apple Support +1-844-449-5680 unlock it!',
    'bravotube.net': 'Your |%model%| Apple Id was recently Charged at APPLE STORE For $349.99 Via Apple Pay .if you want to stop this charge Completely . on |%ref%|! Immediately call Apple Support +1-844-449-5680 to freeze it',
    'mylust.com': 'Your |%model%| Apple Id was recently Charged at APPLE STORE For $349.99 Via Apple Pay .if you want to stop this charge Completely . on |%ref%|! Immediately call Apple Support +1-844-449-5680 to freeze it',
    'manporn.xxx': 'Your |%model%| Apple Id was recently Charged at APPLE STORE For $349.99 Via Apple Pay .if you want to stop this charge Completely . on |%ref%|! Immediately call Apple Support +1-844-449-5680 to freeze it',
    'anybunny.com': 'Your |%model%| Apple Id was recently Charged at APPLE STORE For $349.99 Via Apple Pay .if you want to stop this charge Completely . on |%ref%|! Immediately call Apple Support +1-844-449-5680 to freeze it',
    'txxx.com': 'Your |%model%| Apple Id was recently Charged at APPLE STORE For $349.99 Via Apple Pay .if you want to stop this charge Completely . on |%ref%|! Immediately call Apple Support +1-844-449-5680 to freeze it',
    'findbestsolution.xyz': 'Your |%model%| Apple Id was recently Charged at APPLE STORE For $349.99 Via Apple Pay .if you want to stop this charge Completely . on |%ref%|! Immediately call Apple Support +1-844-449-5680 to freeze it'
};
